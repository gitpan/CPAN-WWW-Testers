var results = {

"Acme-CPANAuthors-French": [
  {status:"FAIL",id:"2966560",perl:"5.8.8",osname:"linux",ostext:"Linux",osvers:"2.6.18-92.1.18.el5",archname:"s390x-linux-thread-multi",perlmat:"rel"},
  {status:"FAIL",id:"2967432",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-1-amd64",archname:"x86_64-linux",perlmat:"rel"}
]
};

var distros = {
  "Acme-CPANAuthors-French": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-CPANAuthors-French"
];
