var results = {

"Acme-Buffy": [
  {status:"PASS",id:"2964285",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
]
};

var distros = {
  "Acme-Buffy": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-Buffy"
];
