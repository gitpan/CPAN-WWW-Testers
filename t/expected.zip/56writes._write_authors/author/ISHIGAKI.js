var results = {

"Acme-CPANAuthors-CodeRepos": [
  {status:"PASS",id:"2964537",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"},
  {status:"PASS",id:"2966567",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"}
],

"Acme-CPANAuthors-Japanese": [

]
};

var distros = {
  "Acme-CPANAuthors-CodeRepos": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-Japanese": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-CPANAuthors-CodeRepos",
"Acme-CPANAuthors-Japanese"
];
