var results = {

"AI-NeuralNet-BackProp": [
  {status:"PASS",id:"2965930",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"AI-NeuralNet-Mesh": [
  {status:"PASS",id:"2965931",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
]
};

var distros = {
  "AI-NeuralNet-BackProp": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-Mesh": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"AI-NeuralNet-BackProp",
"AI-NeuralNet-Mesh"
];
