var results = {

"AI-NeuralNet-SOM": [
  {status:"PASS",id:"2966360",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"}
]
};

var distros = {
  "AI-NeuralNet-SOM": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"AI-NeuralNet-SOM"
];
