var results = {

"Acme-CPANAuthors-Canadian": [
  {status:"PASS",id:"2966541",perl:"5.8.8",osname:"linux",ostext:"Linux",osvers:"2.6.18-92.1.18.el5",archname:"s390x-linux-thread-multi",perlmat:"rel"}
]
};

var distros = {
  "Acme-CPANAuthors-Canadian": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-CPANAuthors-Canadian"
];
