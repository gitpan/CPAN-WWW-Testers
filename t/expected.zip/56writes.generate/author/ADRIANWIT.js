var results = {

"Abstract-Meta-Class": [

]
};

var distros = {
  "Abstract-Meta-Class": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Abstract-Meta-Class"
];
