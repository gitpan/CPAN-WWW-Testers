var results = {

"Acme-Buffy": [
  {status:"UNKNOWN",id:"1396564",perl:"5.5.5",osname:"freebsd",ostext:"FREEBSD",osvers:"6.1-release",archname:"i386-freebsd",perlmat:"rel"},
  {status:"FAIL",id:"2613077",perl:"5.8.9",osname:"freebsd",ostext:"FREEBSD",osvers:"6.1-release-p23",archname:"i386-freebsd",perlmat:"rel"},
  {status:"PASS",id:"2964285",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
]
};

var distros = {
  "Acme-Buffy": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-Buffy"
];
