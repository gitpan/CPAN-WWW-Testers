var results = {

"Acme-Brainfuck": [
  {status:"PASS",id:"2965412",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
]
};

var distros = {
  "Acme-Brainfuck": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"Acme-Brainfuck"
];
