var results = {

"AI-NeuralNet-SOM": [
  {status:"NA",id:"1544358",perl:"5.8.3",osname:"darwin",ostext:"Darwin",osvers:"7.9.0",archname:"darwin-2level",perlmat:"rel"},
  {status:"NA",id:"1587804",perl:"5.8.1",osname:"darwin",ostext:"Darwin",osvers:"7.9.0",archname:"darwin-2level",perlmat:"rel"},
  {status:"PASS",id:"2966360",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"}
]
};

var distros = {
  "AI-NeuralNet-SOM": [ {oncpan:"cpan", distmat:"off"} ]
};

var versions = [
"AI-NeuralNet-SOM"
];
