var results = {

"AI-NeuralNet-SOM-0.07": [
  {status:"PASS",id:"2966360",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"},
  {status:"NA",id:"1587804",perl:"5.8.1",osname:"darwin",ostext:"Darwin",osvers:"7.9.0",archname:"darwin-2level",perlmat:"rel"},
  {status:"NA",id:"1544358",perl:"5.8.3",osname:"darwin",ostext:"Darwin",osvers:"7.9.0",archname:"darwin-2level",perlmat:"rel"}
],

"AI-NeuralNet-SOM-0.06": [

],

"AI-NeuralNet-SOM-0.05": [

],

"AI-NeuralNet-SOM-0.04": [

],

"AI-NeuralNet-SOM-0.03": [

],

"AI-NeuralNet-SOM-0.02": [
  {status:"FAIL",id:"2603754",perl:"5.8.8 patch 34559",osname:"solaris",ostext:"SOLARIS",osvers:"2.11",archname:"i86pc-solaris-64int",perlmat:"rel"},
  {status:"UNKNOWN",id:"1994346",perl:"5.6.2",osname:"freebsd",ostext:"FREEBSD",osvers:"6.1-release",archname:"i386-freebsd",perlmat:"rel"}
],

"AI-NeuralNet-SOM-0.01": [

]
};


var distros = {
  "AI-NeuralNet-SOM-0.07": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.06": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.05": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.04": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.03": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.02": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.01": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AI-NeuralNet-SOM-0.07",
  "AI-NeuralNet-SOM-0.06",
  "AI-NeuralNet-SOM-0.05",
  "AI-NeuralNet-SOM-0.04",
  "AI-NeuralNet-SOM-0.03",
  "AI-NeuralNet-SOM-0.02",
  "AI-NeuralNet-SOM-0.01"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


