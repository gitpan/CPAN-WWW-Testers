var results = {

"Acme-CPANAuthors-Canadian-0.0101": [
  {status:"PASS",id:"2966541",perl:"5.8.8",osname:"linux",ostext:"LINUX",osvers:"2.6.18-92.1.18.el5",archname:"s390x-linux-thread-multi",perlmat:"rel"},
  {status:"PASS",id:"2725989",perl:"5.10.0",osname:"mswin32",ostext:"MSWin32",osvers:"5.00",archname:"MSWin32-x86-multi-thread",perlmat:"rel"}
]
};


var distros = {
  "Acme-CPANAuthors-Canadian-0.0101": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "Acme-CPANAuthors-Canadian-0.0101"
];


var stats = [
  {perl: "5.10.0", counts: [ "", "1" ] },
  {perl: "5.8.8", counts: [ "1", "" ] }
];


