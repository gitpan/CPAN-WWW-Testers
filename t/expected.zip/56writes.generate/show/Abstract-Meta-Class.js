var results = {

"Abstract-Meta-Class-0.13": [

],

"Abstract-Meta-Class-0.12": [

],

"Abstract-Meta-Class-0.11": [
  {status:"PASS",id:"2970367",perl:"5.11.0 patch GitLive-blead-163-g28b1dae",osname:"linux",ostext:"LINUX",osvers:"2.6.24-19-generic",archname:"i686-linux-thread-multi",perlmat:"dev"},
  {status:"PASS",id:"2969663",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-19-generic",archname:"i686-linux-thread-multi",perlmat:"rel"},
  {status:"PASS",id:"2969661",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-19-generic",archname:"i686-linux-thread-multi",perlmat:"rel"},
  {status:"PASS",id:"2969433",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-19-generic",archname:"i686-linux-thread-multi",perlmat:"rel"},
  {status:"PASS",id:"2959417",perl:"5.10.0",osname:"MSWin32",ostext:"MSWin32",osvers:"5.1",archname:"MSWin32-x86-multi-thread",perlmat:"rel"}
],

"Abstract-Meta-Class-0.10": [
  {status:"NA",id:"1717321",perl:"5.5.5",osname:"freebsd",ostext:"FREEBSD",osvers:"6.1-release",archname:"i386-freebsd",perlmat:"rel"}
],

"Abstract-Meta-Class-0.09": [

],

"Abstract-Meta-Class-0.08": [

],

"Abstract-Meta-Class-0.07": [

],

"Abstract-Meta-Class-0.06": [

],

"Abstract-Meta-Class-0.05": [

],

"Abstract-Meta-Class-0.04": [

],

"Abstract-Meta-Class-0.03": [

],

"Abstract-Meta-Class-0.01": [

]
};


var distros = {
  "Abstract-Meta-Class-0.13": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.12": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.11": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.10": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.09": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.08": [ {oncpan:"cpan", distmat:"off"} ],
  "Abstract-Meta-Class-0.07": [ {oncpan:"back", distmat:"off"} ],
  "Abstract-Meta-Class-0.06": [ {oncpan:"back", distmat:"off"} ],
  "Abstract-Meta-Class-0.05": [ {oncpan:"back", distmat:"off"} ],
  "Abstract-Meta-Class-0.04": [ {oncpan:"back", distmat:"off"} ],
  "Abstract-Meta-Class-0.03": [ {oncpan:"back", distmat:"off"} ],
  "Abstract-Meta-Class-0.01": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Abstract-Meta-Class-0.13",
  "Abstract-Meta-Class-0.12",
  "Abstract-Meta-Class-0.11",
  "Abstract-Meta-Class-0.10",
  "Abstract-Meta-Class-0.09",
  "Abstract-Meta-Class-0.08",
  "Abstract-Meta-Class-0.07",
  "Abstract-Meta-Class-0.06",
  "Abstract-Meta-Class-0.05",
  "Abstract-Meta-Class-0.04",
  "Abstract-Meta-Class-0.03",
  "Abstract-Meta-Class-0.01"
];


var stats = [
  {perl: "5.11.0 patch GitLive-blead-163-g28b1dae", counts: [ "1", "" ] },
  {perl: "5.10.0", counts: [ "3", "1" ] }
];


