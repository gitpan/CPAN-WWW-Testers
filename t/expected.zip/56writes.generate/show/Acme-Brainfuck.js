var results = {

"Acme-Brainfuck-1.1.1": [
  {status:"PASS",id:"2965412",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"Acme-Brainfuck-1.1.0": [

],

"Acme-Brainfuck-1.0.0": [

]
};


var distros = {
  "Acme-Brainfuck-1.1.1": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-Brainfuck-1.1.0": [ {oncpan:"back", distmat:"off"} ],
  "Acme-Brainfuck-1.0.0": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Acme-Brainfuck-1.1.1",
  "Acme-Brainfuck-1.1.0",
  "Acme-Brainfuck-1.0.0"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


