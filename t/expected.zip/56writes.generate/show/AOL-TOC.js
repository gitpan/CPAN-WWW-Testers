var results = {

"AOL-TOC-0.340": [
  {status:"PASS",id:"2967174",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"AOL-TOC-0.33": [

],

"AOL-TOC-0.32": [

]
};


var distros = {
  "AOL-TOC-0.340": [ {oncpan:"cpan", distmat:"off"} ],
  "AOL-TOC-0.33": [ {oncpan:"cpan", distmat:"off"} ],
  "AOL-TOC-0.32": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AOL-TOC-0.340",
  "AOL-TOC-0.33",
  "AOL-TOC-0.32"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


