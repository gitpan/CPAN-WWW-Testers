var results = {

"Acme-CPANAuthors-CodeRepos-0.080522": [
  {status:"PASS",id:"2966567",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"},
  {status:"PASS",id:"2964537",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
]
};


var distros = {
  "Acme-CPANAuthors-CodeRepos-0.080522": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "Acme-CPANAuthors-CodeRepos-0.080522"
];


var stats = [
  {perl: "5.10.0", counts: [ "2" ] }
];


