var results = {

"Acme-Anything-0.02": [
  {status:"PASS",id:"2967647",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"Acme-Anything-0.01": [

]
};


var distros = {
  "Acme-Anything-0.02": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-Anything-0.01": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Acme-Anything-0.02",
  "Acme-Anything-0.01"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


