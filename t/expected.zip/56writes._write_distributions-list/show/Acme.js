var results = {

"Acme-1.11111": [
  {status:"PASS",id:"2964284",perl:"5.10.0",osname:"linux",ostext:"LINUX",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"Acme-1.1111": [

],

"Acme-1.111": [

],

"Acme-1.11": [

],

"Acme-1.00": [

]
};


var distros = {
  "Acme-1.11111": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-1.1111": [ {oncpan:"back", distmat:"off"} ],
  "Acme-1.111": [ {oncpan:"back", distmat:"off"} ],
  "Acme-1.11": [ {oncpan:"back", distmat:"off"} ],
  "Acme-1.00": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Acme-1.11111",
  "Acme-1.1111",
  "Acme-1.111",
  "Acme-1.11",
  "Acme-1.00"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


