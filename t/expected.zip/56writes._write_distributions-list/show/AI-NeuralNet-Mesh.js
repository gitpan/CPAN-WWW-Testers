var results = {

"AI-NeuralNet-Mesh-0.44": [
  {status:"PASS",id:"2965931",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"AI-NeuralNet-Mesh-0.43": [

],

"AI-NeuralNet-Mesh-0.31": [

],

"AI-NeuralNet-Mesh-0.20": [

]
};


var distros = {
  "AI-NeuralNet-Mesh-0.44": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-Mesh-0.43": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-Mesh-0.31": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-Mesh-0.20": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AI-NeuralNet-Mesh-0.44",
  "AI-NeuralNet-Mesh-0.43",
  "AI-NeuralNet-Mesh-0.31",
  "AI-NeuralNet-Mesh-0.20"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


