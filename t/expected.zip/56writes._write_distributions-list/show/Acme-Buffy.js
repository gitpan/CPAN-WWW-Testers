var results = {

"Acme-Buffy-1.5": [
  {status:"PASS",id:"2964285",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"Acme-Buffy-1.4": [

],

"Acme-Buffy-1.3": [

],

"Acme-Buffy-1.2": [

],

"Acme-Buffy-1.1": [

]
};


var distros = {
  "Acme-Buffy-1.5": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-Buffy-1.4": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-Buffy-1.3": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-Buffy-1.2": [ {oncpan:"back", distmat:"off"} ],
  "Acme-Buffy-1.1": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Acme-Buffy-1.5",
  "Acme-Buffy-1.4",
  "Acme-Buffy-1.3",
  "Acme-Buffy-1.2",
  "Acme-Buffy-1.1"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


