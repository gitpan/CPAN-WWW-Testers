var results = {

"AI-NeuralNet-BackProp-0.89": [
  {status:"PASS",id:"2965930",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"AI-NeuralNet-BackProp-0.77": [

],

"AI-NeuralNet-BackProp-0.42": [

],

"AI-NeuralNet-BackProp-0.40": [

]
};


var distros = {
  "AI-NeuralNet-BackProp-0.89": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-BackProp-0.77": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-BackProp-0.42": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-BackProp-0.40": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AI-NeuralNet-BackProp-0.89",
  "AI-NeuralNet-BackProp-0.77",
  "AI-NeuralNet-BackProp-0.42",
  "AI-NeuralNet-BackProp-0.40"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


