var results = {

"Acme-BOPE-0.01": [
  {status:"PASS",id:"2966429",perl:"5.8.8",osname:"linux",ostext:"Linux",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"}
]
};


var distros = {
  "Acme-BOPE-0.01": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "Acme-BOPE-0.01"
];


var stats = [
  {perl: "5.8.8", counts: [ "1" ] }
];


