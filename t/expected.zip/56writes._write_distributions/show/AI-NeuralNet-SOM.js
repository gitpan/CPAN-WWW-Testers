var results = {

"AI-NeuralNet-SOM-0.07": [
  {status:"PASS",id:"2966360",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.16.60-0.31-default",archname:"s390x-linux",perlmat:"rel"}
],

"AI-NeuralNet-SOM-0.06": [

],

"AI-NeuralNet-SOM-0.05": [

],

"AI-NeuralNet-SOM-0.04": [

],

"AI-NeuralNet-SOM-0.03": [

],

"AI-NeuralNet-SOM-0.02": [

],

"AI-NeuralNet-SOM-0.01": [

]
};


var distros = {
  "AI-NeuralNet-SOM-0.07": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.06": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.05": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.04": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.03": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.02": [ {oncpan:"cpan", distmat:"off"} ],
  "AI-NeuralNet-SOM-0.01": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AI-NeuralNet-SOM-0.07",
  "AI-NeuralNet-SOM-0.06",
  "AI-NeuralNet-SOM-0.05",
  "AI-NeuralNet-SOM-0.04",
  "AI-NeuralNet-SOM-0.03",
  "AI-NeuralNet-SOM-0.02",
  "AI-NeuralNet-SOM-0.01"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


