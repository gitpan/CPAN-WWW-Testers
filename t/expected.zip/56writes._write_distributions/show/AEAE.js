var results = {

"AEAE-0.02": [
  {status:"PASS",id:"2966771",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"AEAE-0.01": [

]
};


var distros = {
  "AEAE-0.02": [ {oncpan:"cpan", distmat:"off"} ],
  "AEAE-0.01": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "AEAE-0.02",
  "AEAE-0.01"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


