var results = {

"Acme-CPANAuthors-Japanese-0.090101": [

],

"Acme-CPANAuthors-Japanese-0.080522": [
  {status:"PASS",id:"2964541",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-etchnhalf.1-amd64",archname:"x86_64-linux-thread-multi-ld",perlmat:"rel"}
],

"Acme-CPANAuthors-Japanese-0.071226": [

]
};


var distros = {
  "Acme-CPANAuthors-Japanese-0.090101": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-Japanese-0.080522": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-Japanese-0.071226": [ {oncpan:"cpan", distmat:"off"} ]
};


var versions = [
  "Acme-CPANAuthors-Japanese-0.090101",
  "Acme-CPANAuthors-Japanese-0.080522",
  "Acme-CPANAuthors-Japanese-0.071226"
];


var stats = [
  {perl: "5.10.0", counts: [ "1" ] }
];


