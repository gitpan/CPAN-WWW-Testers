var results = {

"Acme-CPANAuthors-French-0.07": [
  {status:"FAIL",id:"2967432",perl:"5.10.0",osname:"linux",ostext:"Linux",osvers:"2.6.24-1-amd64",archname:"x86_64-linux",perlmat:"rel"},
  {status:"FAIL",id:"2966560",perl:"5.8.8",osname:"linux",ostext:"Linux",osvers:"2.6.18-92.1.18.el5",archname:"s390x-linux-thread-multi",perlmat:"rel"}
],

"Acme-CPANAuthors-French-0.06": [

],

"Acme-CPANAuthors-French-0.05": [

],

"Acme-CPANAuthors-French-0.04": [

],

"Acme-CPANAuthors-French-0.03": [

],

"Acme-CPANAuthors-French-0.02": [

],

"Acme-CPANAuthors-French-0.01": [

]
};


var distros = {
  "Acme-CPANAuthors-French-0.07": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.06": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.05": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.04": [ {oncpan:"cpan", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.03": [ {oncpan:"back", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.02": [ {oncpan:"back", distmat:"off"} ],
  "Acme-CPANAuthors-French-0.01": [ {oncpan:"back", distmat:"off"} ]
};


var versions = [
  "Acme-CPANAuthors-French-0.07",
  "Acme-CPANAuthors-French-0.06",
  "Acme-CPANAuthors-French-0.05",
  "Acme-CPANAuthors-French-0.04",
  "Acme-CPANAuthors-French-0.03",
  "Acme-CPANAuthors-French-0.02",
  "Acme-CPANAuthors-French-0.01"
];


var stats = [

];


